#from . import Components as components

#Sawyer: Initialize APWorld. Looks like it's all in .World, so this file basically just runs that file
from .World import SDWorld as SDWorld

